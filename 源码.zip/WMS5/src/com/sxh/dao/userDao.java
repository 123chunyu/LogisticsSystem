package com.sxh.dao;

import java.sql.SQLException;
import java.util.List;

import com.sxh.pojo.Admin;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public interface userDao {
	public Admin selectAllAdmin(String name,String password) throws SQLException;
	public User selectAllUser(String name,String password) throws SQLException;
	public Good selectAllGood(String name,String password) throws SQLException;
	public List<Object> selectUserList() throws SQLException;
	public List<Object> selectUserList(String page,String limit) throws SQLException;
	public int countUser() throws SQLException;
	public List<Object> selectGoodList() throws SQLException;
	public List<Object> selectGoodList(String pageStr, String limitStr) throws SQLException;
	public int countGood() throws SQLException;
	public List<Object> findGoodList(String page, String limit) throws SQLException;
	public List<Object> findAllUser(String page, String limit) throws SQLException;
	public List<Object> findUser(String name) throws SQLException;
	public List<Object> findGood(String gname) throws SQLException;
	//public int  DelUser(String userId,String name,String sex,String age,String tel,String QQ,String entity) throws SQLException;
	public int addUser(User user) throws SQLException;
}
