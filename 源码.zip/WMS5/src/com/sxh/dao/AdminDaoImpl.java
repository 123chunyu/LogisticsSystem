package com.sxh.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.sxh.pojo.Good;
import com.sxh.pojo.User;
import com.sxh.utils.DBUtil;

public class AdminDaoImpl implements AdminDao {

	@Override
	public int Adduser(User user) throws SQLException {
		// TODO Auto-generated method stub
		int rs;
		int rs2;
		
		DBUtil dbUtil=new DBUtil();
		
		String sql="insert into s_user(userId,name,password) values(?,?,?)";
		String sql2="insert into userinfo(userId,name,sex,age,tel,qQ,entity) values(?,?,?,?,?,?,?)";
		

		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=(PreparedStatement)dbUtil.getPreparedStatement(sql2);
		
		ps.setString(1,user.getUserId());
		ps.setString(2,user.getName());
		ps.setString(3,user.getPassword());
		
		ps2.setString(1,user.getUserId());
		ps2.setString(2,user.getName());
		ps2.setString(3,user.getSex());
		ps2.setString(4,user.getAge());
		ps2.setString(5,user.getTel());
		ps2.setString(6,user.getQQ());
		ps2.setString(7,user.getEntity());
		
		
		rs=ps.executeUpdate();
		rs2=ps2.executeUpdate();
	//	System.out.println(rs2);
		if(rs==1&&rs2==1) {
			dbUtil.commit();
			return 1;
		}else {
			return 0;
		}
	}

	@Override
	public int Addgood(Good good) throws SQLException {
		// TODO Auto-generated method stub
		int rs;

		
		DBUtil dbUtil=new DBUtil();
		
	
		String sql="insert into goodinfo(goodId,gname,number,price,supplier,phone) values(?,?,?,?,?,?)";
		

		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		
		ps.setString(1,good.getGoodId());
		ps.setString(2,good.getGname());
		ps.setString(3,good.getNumber());
		ps.setString(4,good.getPrice());
		ps.setString(5,good.getSupplier());
		ps.setString(6,good.getPhone());
		

		
		rs=ps.executeUpdate();
	//	System.out.println(rs2);
		if(rs==1) {
			dbUtil.commit();
			return 1;
		}else {
			return 0;
		}
	}
}
