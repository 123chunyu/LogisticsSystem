package com.sxh.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;
import com.sxh.pojo.Admin;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;
import com.sxh.utils.DBUtil;

public class userDaoImpl implements userDao {
	
	@Override
	public Admin selectAllAdmin(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();

		String sql="select*from s_admin where name=? and password=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password); 
		ResultSet rs=ps.executeQuery();
		Admin admin=new Admin();
		while(rs.next()) {
			admin.setName(rs.getString("name"));
			admin.setPassword(rs.getString("password"));
			return admin;
		}
		
		return null;
	}

	@Override
	public User selectAllUser(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();

		String sql="select*from s_user where name=? and password=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password); 
		ResultSet rs=ps.executeQuery();
		User user=new User();
		while(rs.next()) {
			user.setName(rs.getString("name"));;
			user.setPassword(rs.getString("password"));;
			return user;
		}
		return null;
	}
	
	@Override
	public Good selectAllGood(String name, String password) throws SQLException{
		// TODO Auto-generated method stub
		
		DBUtil dbUtil=new DBUtil();

		String sql="select*from s_good where name=? and password=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password); 
		ResultSet rs=ps.executeQuery();
		Good good=new Good();
		while(rs.next()) {
			good.setGname(rs.getString("name"));;
			good.setPassword(rs.getString("password"));;
			return good;
		}
		return null;
	}

	@Override
	public List<Object> selectUserList() throws SQLException {
		DBUtil dbUtil=new DBUtil();
		String sql="select * from userinfo";
		Statement st=(Statement)dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		java.util.List<Object> list=new ArrayList<Object>();
	//	java.util.List<Object> list=null;
		while(rs.next()) {
			User user=new User();
			user.setUserId(rs.getString("userId"));
			user.setName(rs.getString("name"));
			//user.setPassword(rs.getString("password"));
			user.setSex(rs.getString("sex"));
			user.setAge(rs.getString("age"));
			user.setTel(rs.getString("tel"));
			user.setQQ(rs.getString("qQ"));
			user.setEntity(rs.getString("entity"));
			list.add(user);
		}
		return list;
	}

	@Override
	public List<Object> selectUserList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from userinfo limit ?,?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		int page1=Integer.parseInt(page);
		int limit1=Integer.parseInt(limit);
		ps.setInt(1, (page1-1)*limit1);
		ps.setInt(2, limit1);
		ResultSet rs=ps.executeQuery();
		java.util.List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			User user=new User();
			user.setUserId(rs.getString("userId"));
			user.setName(rs.getString("name"));
			//user.setPassword(rs.getString("password"));
			user.setSex(rs.getString("sex"));
			user.setAge(rs.getString("age"));
			user.setTel(rs.getString("tel"));
			user.setQQ(rs.getString("qQ"));
			user.setEntity(rs.getString("entity"));
			list.add(user);
		}
		return list;
	}

	@Override
	public int countUser() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select count(*) as sum from userinfo";
		Statement st=(Statement)dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			rs.getInt("sum");
		}
		
		return 0;
	}

	@Override
	public List<Object> selectGoodList() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from goodinfo";
		Statement st=(Statement)dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		java.util.List<Object> list=new ArrayList<Object>();
	//	java.util.List<Object> list=null;
		while(rs.next()) {
			Good good=new Good();
			good.setGoodId(rs.getString("goodId"));
			good.setGname(rs.getString("gname"));
			//good.setPassword(rs.getString("password"));
			good.setNumber(rs.getString("number"));
			good.setPrice(rs.getString("price"));
			good.setSupplier(rs.getString("supplier"));
			good.setPhone(rs.getString("phone"));
			list.add(good);
		}
		return list;
	}

	@Override
	public List<Object> selectGoodList(String pageStr, String limitStr) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from goodinfo limit ?,?";
		Statement st=(Statement)dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		java.util.List<Object> list=new ArrayList<Object>();
	//	java.util.List<Object> list=null;
		while(rs.next()) {
			Good good=new Good();
			good.setGoodId(rs.getString("goodId"));
			good.setGname(rs.getString("gname"));
			//good.setPassword(rs.getString("password"));
			good.setNumber(rs.getString("number"));
			good.setPrice(rs.getString("price"));
			good.setSupplier(rs.getString("supplier"));
			good.setPhone(rs.getString("phone"));
			list.add(good);
		}
		return list;
	}

	@Override
	public int countGood() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select count(*) as sum from goodinfo";
		Statement st=(Statement)dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			rs.getInt("sum");
		}
		
		return 0;
	}

	@Override
	public List<Object> findGoodList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
				DBUtil dbUtil=new DBUtil();
				String sql="select * from goodinfo limit ?,?";
				PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
				int page1=Integer.parseInt(page);
				int limit1=Integer.parseInt(limit);
				ps.setInt(1, (page1-1)*limit1);
				ps.setInt(2, limit1);
				ResultSet rs=ps.executeQuery();
				java.util.List<Object> list=new ArrayList<Object>();
				while(rs.next()) {
					Good good=new Good();
					good.setGoodId(rs.getString("goodId"));
					good.setGname(rs.getString("gname"));
					//good.setPassword(rs.getString("password"));
					good.setNumber(rs.getString("number"));
					good.setPrice(rs.getString("price"));
					good.setSupplier(rs.getString("supplier"));
					good.setPhone(rs.getString("phone"));
					list.add(good);
				}
				return list;
	}

	@Override
	public List<Object> findAllUser(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
				DBUtil dbUtil=new DBUtil();
				String sql="select * from userinfo limit ?,?";
				PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
				int page1=Integer.parseInt(page);
				int limit1=Integer.parseInt(limit);
				ps.setInt(1, (page1-1)*limit1);
				ps.setInt(2, limit1);
				ResultSet rs=ps.executeQuery();
				java.util.List<Object> list=new ArrayList<Object>();
				while(rs.next()) {
					User user=new User();
					user.setUserId(rs.getString("userId"));
					user.setName(rs.getString("name"));
					//user.setPassword(rs.getString("password"));
					user.setSex(rs.getString("sex"));
					user.setAge(rs.getString("age"));
					user.setTel(rs.getString("tel"));
					user.setQQ(rs.getString("qQ"));
					user.setEntity(rs.getString("entity"));
					list.add(user);
				}
				return list;
	}

	@Override
	public List<Object> findUser(String name) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from userinfo where name like '%"+name+"%'";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		ResultSet rs=ps.executeQuery();
		java.util.List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			User user=new User();
			user.setUserId(rs.getString("userId"));
			user.setName(rs.getString("name"));
			//user.setPassword(rs.getString("password"));
			user.setSex(rs.getString("sex"));
			user.setAge(rs.getString("age"));
			user.setTel(rs.getString("tel"));
			user.setQQ(rs.getString("qQ"));
			user.setEntity(rs.getString("entity"));
			list.add(user);
		}
		return list;
	}

	@Override
	public List<Object> findGood(String gname) throws SQLException {
		// TODO Auto-generated method stub
				DBUtil dbUtil=new DBUtil();
				String sql="select * from goodinfo where gname like '%"+gname+"%'";
				PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
				ResultSet rs=ps.executeQuery();
				java.util.List<Object> list=new ArrayList<Object>();
				while(rs.next()) {
					Good good=new Good();
					good.setGoodId(rs.getString("goodId"));
					good.setGname(rs.getString("gname"));
					good.setNumber(rs.getString("number"));
					good.setPrice(rs.getString("price"));
					good.setSupplier(rs.getString("supplier"));
					good.setPhone(rs.getString("phone"));
					list.add(good);
				}
				return list;
	}

	

	@Override
	public int addUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_user(name,password,userId) values(?,?,?)";
		String sql2="insert into userinfo(userId,name) values(?,?)";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=(PreparedStatement)dbUtil.getPreparedStatement(sql2);//预编译
		ps.setString(1, user.getName());
		ps.setString(2, user.getPassword());
		ps.setString(3, user.getUserId());
		ps2.setString(1, user.getUserId());
		ps2.setString(2, user.getName());
	
		System.out.print(ps);
		int rs=ps.executeUpdate();
		int rs2=ps2.executeUpdate();
		
		if(rs==1&&rs2==1) {
			
			return 1;
		}else {
			dbUtil.connectionRollback();
			return 0;
		}
	
	}

	/*@Override
	public int DelUser(String name) throws SQLException {
		// TODO Auto-generated method stub
				DBUtil dbUtil=new DBUtil();
				String sql="delete from userinfo where name=?";
				PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
				ps.setString(1,userId);
				ps.setString(2,name);
				ps.setString(3,sex);
				ps.setString(4, age);
				ps.setString(5, tel);
				ps.setString(6, QQ);
				ps.setString(7, entity);	
				int rs=ps.executeUpdate();
				if(rs==1) {
					return 1;
				}else {
					return 0;
				}
			}*/
	


	
	
	
	

}
