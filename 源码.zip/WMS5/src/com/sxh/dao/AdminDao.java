package com.sxh.dao;

import java.sql.SQLException;

import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public interface AdminDao {
	public int Adduser(User user) throws SQLException;
	public int Addgood(Good good) throws SQLException;
}
