package com.sxh.dao;

import java.sql.SQLException;

import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public interface editDao {
	public int EditUser(User user) throws SQLException;
	public int EditGood(Good good) throws SQLException;
	public int DelUser(User user) throws SQLException;
	public int DelGood(Good good) throws SQLException;
}
