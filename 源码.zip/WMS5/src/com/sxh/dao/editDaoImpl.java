package com.sxh.dao;

import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;
import com.sxh.utils.DBUtil;

public class editDaoImpl implements editDao {

	@Override
	public int EditUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="update userinfo set name=?,sex=?,age=?,tel=?,qQ=?,entity=? where userId=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
	
		ps.setString(1, user.getName());
		ps.setString(2, user.getSex());
		ps.setString(3, user.getAge());
		ps.setString(4, user.getTel());
		ps.setString(5, user.getQQ());
		ps.setString(6, user.getEntity());
		ps.setString(7, user.getUserId());
		
		System.out.print(ps);
		
		int rs=ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
			return 0;
	}

	@Override
	public int EditGood(Good good) throws SQLException {
		// TODO Auto-generated method stub
		
		DBUtil dbUtil=new DBUtil();
		String sql="update goodinfo set gname=?,number=?,price=?,supplier=?,phone=? where goodId=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		
		ps.setString(1, good.getGname());
		ps.setString(2, good.getNumber());
		ps.setString(3, good.getPrice());
		ps.setString(4, good.getSupplier());
		ps.setString(5, good.getPhone());
		ps.setString(6, good.getGoodId());
		
		int rs=ps.executeUpdate();
		while(rs==1) {
		
			return 1;
		}
			return 0;
	}

	@Override
	public int DelUser(User user) throws SQLException {
		// TODO Auto-generated method stub
				DBUtil dbUtil=new DBUtil();
				String sql="delete from s_user where userId=?";
				String sql2="delete from userinfo where userId=?";
				PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
				PreparedStatement ps2=(PreparedStatement)dbUtil.getPreparedStatement(sql2);
		
				ps.setString(1, user.getUserId());
				ps2.setString(1, user.getUserId());
				int rs=ps.executeUpdate();
				int rs2=ps2.executeUpdate();
				
				System.out.print(ps2);
				
				
				while(rs==1&&rs2==1) {
				
					return 1;
				}
					return 0;
	}

	@Override
	public int DelGood(Good good) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="delete from goodinfo where goodId=?";
		PreparedStatement ps=(PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, good.getGoodId());
		int rs=ps.executeUpdate();		
		System.out.print(ps);
				
		while(rs==1) {		
			return 1;
		}
		return 0;
	}

}
