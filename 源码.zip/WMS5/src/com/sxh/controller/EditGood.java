package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.dao.editDao;
import com.sxh.dao.editDaoImpl;
import com.sxh.pojo.Good;

/**
 * Servlet implementation class EditGood
 */
@WebServlet("/EditGood")
public class EditGood extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditGood() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				//doGet(request, response);
				request.setCharacterEncoding("utf-8");
				response.setCharacterEncoding("utf-8");
				response.setContentType("text/html;charset=utf-8");
				
				String goodId=request.getParameter("goodId");
				String gname=new String(request.getParameter("gname").getBytes("iso-8859-1"),"UTF-8");
				String number=request.getParameter("number");
				String price=request.getParameter("price");
				String supplier=new String(request.getParameter("supplier").getBytes("iso-8859-1"),"UTF-8");
				String phone=request.getParameter("phone");
				
				Good good=new Good();
				good.setGoodId(goodId);
				good.setGname(gname);
				good.setNumber(number);
				good.setPrice(price);
				good.setSupplier(supplier);
				good.setPhone(phone);
				
				editDao editDao=new editDaoImpl();
				try {
					if(editDao.EditGood(good)==1) {
						response.getWriter().write("success");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	}

}
