package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.pojo.User;
import com.sxh.service.AdminService;
import com.sxh.service.AdminServiceImpl;
import com.sxh.service.LoginService;
import com.sxh.service.LoginServletImpl;

/**
 * Servlet implementation class CheckZhuceServlet
 */
@WebServlet("/CheckZhuceServlet")
public class CheckZhuceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService=new LoginServletImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckZhuceServlet(){
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String entity=request.getParameter("entity");
		String userId=request.getParameter("userId");
		
		User user=new User();
		//System.out.print(name+":"+password+":"+userId);
		user.setName(name);
		user.setPassword(password);
		user.setUserId(userId);
		
		if(entity.equals("用户")){
			System.out.print(7);
		try {
				if(loginService.addUser(user)==1) {
					System.out.print(9);
					response.getWriter().write("success");
				}else {
					System.out.print(10);
					response.getWriter().write("fail");
					}
				} catch (SQLException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			}		
		}
		
	}

}
