package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.dao.editDao;
import com.sxh.dao.editDaoImpl;
import com.sxh.dao.userDao;
import com.sxh.dao.userDaoImpl;
import com.sxh.pojo.User;
import com.sxh.service.AdminService;
import com.sxh.service.AdminServiceImpl;

/**
 * Servlet implementation class DelUser
 */
@WebServlet("/DelUser")
public class DelUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminService adminService=new AdminServiceImpl();
	private editDao editdao=new editDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String userId=request.getParameter("userId");
	
		
		User user=new User();
		user.setUserId(userId);

		try {
			System.out.println(3);
			if(adminService.DelUser(user)==1){
				System.out.println(4);
				response.getWriter().write("success");
			}else {
				System.out.println(5);
				response.getWriter().write("fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
		
	}

}
