package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.sxh.dao.userDao;
import com.sxh.dao.userDaoImpl;
import com.sxh.pojo.Vo;

/**
 * Servlet implementation class findAllUser
 */
@WebServlet("/findAllUser")
public class findAllUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public findAllUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pageStr=request.getParameter("page");
		String limitStr=request.getParameter("limit");
		System.out.println(pageStr);
		System.out.println(limitStr);
		userDao userDao=new userDaoImpl();
		try {
			java.util.List<Object> list=userDao.findAllUser(pageStr, limitStr);
			//java.util.List<Object> list=userDao.;
			response.setContentType("text/html;charset=utf-8");
			Vo vo=new Vo();
			vo.setCode(0);
			vo.setMsg("success");
			vo.setCount(userDao.countUser());
			vo.setData(list);
			response.getWriter().write(JSONObject.toJSON(vo).toString());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
