package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.dao.editDao;
import com.sxh.dao.editDaoImpl;
import com.sxh.pojo.User;
import com.sxh.service.AdminService;
import com.sxh.service.AdminServiceImpl;

/**
 * Servlet implementation class EditUser
 */
@WebServlet("/EditUser")
public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminService adminService=new AdminServiceImpl();  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		//System.out.println(2);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String userId=request.getParameter("userId");
		String name= new String(request.getParameter("name").getBytes("iso-8859-1"),"UTF-8");
		String sex=new String(request.getParameter("sex").getBytes("iso-8859-1"),"UTF-8");
		String age=request.getParameter("age");
		String tel=request.getParameter("tel");
		String qQ=request.getParameter("qQ");
		String entity=new String(request.getParameter("entity").getBytes("iso-8859-1"),"UTF-8");
	
		User user=new User();
		user.setUserId(userId);
		user.setName(name);
		user.setSex(sex);
		user.setAge(age);
		user.setTel(tel);
		user.setQQ(qQ);
		user.setEntity(entity);
       System.out.println(name+entity);			
	   try {
				if(adminService.Edituser(user)==1){
					System.out.println(5);
					response.getWriter().write("success");
				}else{
					System.out.println(6);
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				 
		
	}

}
