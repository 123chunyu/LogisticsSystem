package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.pojo.User;
import com.sxh.service.AdminService;
import com.sxh.service.AdminServiceImpl;

/**
 * Servlet implementation class Adduser
 */
@WebServlet("/Adduser")
public class Adduser extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private AdminService adminService=new AdminServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Adduser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userId=request.getParameter("userId");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String sex=request.getParameter("sex");
		String age=request.getParameter("age");
		String tel=request.getParameter("tel");
		String qQ=request.getParameter("qQ");
		String entity=request.getParameter("entity");
		
		User user=new User();
		user.setUserId(userId);
		user.setName(name);
		user.setPassword(password);
		user.setSex(sex);
		user.setAge(age);
		user.setTel(tel);
		user.setQQ(qQ);
		user.setEntity(entity);
		
		try {
				if(adminService.Adduser(user)==1) {
					response.getWriter().write("success");
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
	
	}

}
