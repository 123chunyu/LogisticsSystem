package com.sxh.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sxh.dao.editDao;
import com.sxh.dao.editDaoImpl;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;
import com.sxh.service.AdminService;
import com.sxh.service.AdminServiceImpl;

/**
 * Servlet implementation class DelGood
 */
@WebServlet("/DelGood")
public class DelGood extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminService adminService=new AdminServiceImpl();
	private editDao editdao=new editDaoImpl();   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelGood() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		// TODO Auto-generated method stub
				request.setCharacterEncoding("utf-8");
				response.setCharacterEncoding("utf-8");
				response.setContentType("text/html;charset=utf-8");
				
				String goodId=request.getParameter("goodId");
			
				
				Good good=new Good();
				good.setGoodId(goodId);;
		
				try {
					System.out.println(6);
					if(adminService.DelGood(good)==1){
						System.out.println(7);
						response.getWriter().write("success");
					}else {
						System.out.println(8);
						response.getWriter().write("fail");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			
	}

}
