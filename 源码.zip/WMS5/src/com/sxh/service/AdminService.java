package com.sxh.service;

import java.sql.SQLException;

import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public interface AdminService {
	public int Adduser(User user) throws SQLException;
	public int Addgood(Good good) throws SQLException;
	public int Edituser(User user) throws SQLException;
	public int DelUser(User user) throws SQLException;
	public int DelGood(Good good) throws SQLException;
}
