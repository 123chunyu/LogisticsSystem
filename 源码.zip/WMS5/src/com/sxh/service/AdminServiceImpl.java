package com.sxh.service;

import java.sql.SQLException;

import com.sxh.dao.AdminDao;
import com.sxh.dao.AdminDaoImpl;
import com.sxh.dao.editDao;
import com.sxh.dao.editDaoImpl;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public class AdminServiceImpl implements AdminService {

	
	private AdminDao adminDao=new AdminDaoImpl();
	private editDao editDao=new editDaoImpl();
	@Override
	public int Adduser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return adminDao.Adduser(user);
	}

	@Override
	public int Addgood(Good good) throws SQLException {
		// TODO Auto-generated method stub
		return adminDao.Addgood(good);
	}

	@Override
	public int DelUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return editDao.DelUser(user);
	}

	@Override
	public int Edituser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return editDao.EditUser(user);
	}

	@Override
	public int DelGood(Good good) throws SQLException {
		// TODO Auto-generated method stub
		return editDao.DelGood(good);
	}

}
