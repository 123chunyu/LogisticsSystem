package com.sxh.service;

import java.sql.SQLException;
import java.util.List;

import com.sxh.dao.userDao;
import com.sxh.dao.userDaoImpl;
import com.sxh.pojo.Admin;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public class LoginServletImpl implements LoginService {
	private userDao userDao=new userDaoImpl();
	
	@Override
	public Admin selectAllAdmin(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
				return userDao.selectAllAdmin(name, password);
	}

	@Override
	public User selectAllUser(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
				return userDao.selectAllUser(name, password);
	}

	@Override
	public Good selectAllGood(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
				return userDao.selectAllGood(name, password);
	}

	@Override
	public User selectAllUser() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Good selectAllGood() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> findGoodList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.findAllUser(page, limit);
	}

	@Override
	public int addUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
	}

	@Override
	public List<Object> findUserList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
