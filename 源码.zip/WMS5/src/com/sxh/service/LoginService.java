package com.sxh.service;

import java.sql.SQLException;
import java.util.List;

import com.sxh.pojo.Admin;
import com.sxh.pojo.Good;
import com.sxh.pojo.User;

public interface LoginService {
	public Admin selectAllAdmin(String name,String password) throws SQLException;
	public User selectAllUser(String name,String password) throws SQLException;
	public User selectAllUser() throws SQLException;
	public Good selectAllGood(String name,String password) throws SQLException;
	public Good selectAllGood() throws SQLException;
	public List<Object> findGoodList(String page, String limit) throws SQLException;
	public List<Object> findUserList(String page, String limit) throws SQLException;
	public int addUser(User user) throws SQLException;
}
