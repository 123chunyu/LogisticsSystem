package com.sxh.pojo;
import lombok.Data;

@Data
public class Good {
	private String goodId;
	private String gname;
	private String password;
	private String number;
	private String price;
	private String supplier;
	private String phone;

}