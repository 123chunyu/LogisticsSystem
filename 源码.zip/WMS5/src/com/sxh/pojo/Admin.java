package com.sxh.pojo;

import lombok.Data;
@Data
public class Admin {   
    private String name;
    private String password;
}

