package com.sxh.pojo;

import lombok.Data;

@Data
public class User{

	private String userId;
	private String name;
	private String password;
	private String sex;
	private String age;
	private String tel;
	private String qQ;
	private String entity;
}