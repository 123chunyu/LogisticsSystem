package com.sxh.pojo;//与Ajax打交道

import java.util.List;

import lombok.Data;
@Data
public class Vo {
	//返回给前端code，msg,count,data
	int code;
	String msg;
	int count;
	List<Object> data;

}